/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import javax.swing.*;

/**
 *
 * @author VIKASH
 */
public class ConnectSqlDb {
    Connection Conn=null;
public static Connection ConnectDB(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection Conn=DriverManager.getConnection("jdbc:mysql://localhost/","root","")
        JOptionPane.showMessageDialog(null, "Connected to database");
        return Conn;
         }
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e);
    return null;
}  
}
